-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 14, 2016 at 12:48 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gt_getaride`
--

-- --------------------------------------------------------

--
-- Table structure for table `ACCOUNTS`
--

CREATE TABLE `ACCOUNTS` (
  `Accounts_id` int(30) NOT NULL,
  `Last_Name` varchar(30) DEFAULT NULL,
  `First_Name` varchar(30) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Gender` varchar(6) DEFAULT NULL,
  `Phone` varchar(30) DEFAULT NULL,
  `Username` varchar(30) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `DELIVERY`
--

CREATE TABLE `DELIVERY` (
  `Delivery_id` int(30) NOT NULL,
  `Housing_id` int(30) DEFAULT NULL,
  `Host_Address` varchar(30) DEFAULT NULL,
  `Host_Contact` varchar(30) DEFAULT NULL,
  `Nights_Stayng` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `FLIGHT_INFO`
--

CREATE TABLE `FLIGHT_INFO` (
  `Flight_id` int(30) NOT NULL,
  `Student_id` int(30) DEFAULT NULL,
  `Arriving_Flight_Nr` varchar(30) DEFAULT NULL,
  `Arriving_Date` date DEFAULT NULL,
  `Arriving_Time` varchar(30) DEFAULT NULL,
  `Offer_Pickup` char(3) DEFAULT NULL,
  `Departing_Flight_Nr` varchar(30) DEFAULT NULL,
  `Luggage_amount` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `HOUSING_OFFER`
--

CREATE TABLE `HOUSING_OFFER` (
  `Housing_id` int(30) NOT NULL,
  `Volunteer_id` int(30) DEFAULT NULL,
  `Housing_address` varchar(30) DEFAULT NULL,
  `Volunteer_contact` varchar(30) DEFAULT NULL,
  `Nights_offering` int(30) DEFAULT NULL,
  `Max_guests` int(30) DEFAULT NULL,
  `Trip_rounds` int(30) DEFAULT NULL,
  `Period_preference` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Pick_up`
--

CREATE TABLE `Pick_up` (
  `Pick_up_id` int(30) NOT NULL,
  `Student_id` int(30) DEFAULT NULL,
  `Volunteer_id` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Student_acc`
--

CREATE TABLE `Student_acc` (
  `Student_id` int(30) NOT NULL,
  `St_level` varchar(30) DEFAULT NULL,
  `Major` varchar(30) DEFAULT NULL,
  `accounts_id` int(30) DEFAULT NULL,
  `Airport_pickup` char(3) DEFAULT NULL,
  `Require_housing` char(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `VOLUNTEER`
--

CREATE TABLE `VOLUNTEER` (
  `Volunteer_id` int(30) NOT NULL,
  `accounts_id` int(30) DEFAULT NULL,
  `Affiliation` varchar(30) DEFAULT NULL,
  `Period_Preference` varchar(30) DEFAULT NULL,
  `Lugage_Limit` int(30) DEFAULT NULL,
  `Offer_Pickup` char(3) DEFAULT NULL,
  `Offer_Housing` char(3) DEFAULT NULL,
  `Trip_rounds` int(30) DEFAULT NULL,
  `Pick_up_limit` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ACCOUNTS`
--
ALTER TABLE `ACCOUNTS`
  ADD PRIMARY KEY (`Accounts_id`);

--
-- Indexes for table `DELIVERY`
--
ALTER TABLE `DELIVERY`
  ADD PRIMARY KEY (`Delivery_id`),
  ADD KEY `Delivery_Hous_Housing_id_pk` (`Housing_id`);

--
-- Indexes for table `FLIGHT_INFO`
--
ALTER TABLE `FLIGHT_INFO`
  ADD PRIMARY KEY (`Flight_id`),
  ADD KEY `Flight_Student_id_pk` (`Student_id`);

--
-- Indexes for table `HOUSING_OFFER`
--
ALTER TABLE `HOUSING_OFFER`
  ADD PRIMARY KEY (`Housing_id`),
  ADD KEY `Housing_Volunteer_ID_pk` (`Volunteer_id`);

--
-- Indexes for table `Pick_up`
--
ALTER TABLE `Pick_up`
  ADD PRIMARY KEY (`Pick_up_id`),
  ADD KEY `Pickup_Student_id_pk` (`Student_id`),
  ADD KEY `Pickup_Volunteer_ID_pk` (`Volunteer_id`);

--
-- Indexes for table `Student_acc`
--
ALTER TABLE `Student_acc`
  ADD PRIMARY KEY (`Student_id`),
  ADD KEY `Student_acc_acc_id_pk` (`accounts_id`);

--
-- Indexes for table `VOLUNTEER`
--
ALTER TABLE `VOLUNTEER`
  ADD PRIMARY KEY (`Volunteer_id`),
  ADD KEY `volunteer_acc_id_pk` (`accounts_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `DELIVERY`
--
ALTER TABLE `DELIVERY`
  ADD CONSTRAINT `Delivery_Hous_Housing_id_pk` FOREIGN KEY (`Housing_id`) REFERENCES `Housing_Offer` (`Housing_id`);

--
-- Constraints for table `FLIGHT_INFO`
--
ALTER TABLE `FLIGHT_INFO`
  ADD CONSTRAINT `Flight_Student_id_pk` FOREIGN KEY (`Student_id`) REFERENCES `Student_acc` (`Student_id`);

--
-- Constraints for table `HOUSING_OFFER`
--
ALTER TABLE `HOUSING_OFFER`
  ADD CONSTRAINT `Housing_Volunteer_ID_pk` FOREIGN KEY (`Volunteer_id`) REFERENCES `Volunteer` (`Volunteer_id`);

--
-- Constraints for table `Pick_up`
--
ALTER TABLE `Pick_up`
  ADD CONSTRAINT `Pickup_Student_id_pk` FOREIGN KEY (`Student_id`) REFERENCES `Student_acc` (`Student_id`),
  ADD CONSTRAINT `Pickup_Volunteer_ID_pk` FOREIGN KEY (`Volunteer_id`) REFERENCES `Volunteer` (`Volunteer_id`);

--
-- Constraints for table `Student_acc`
--
ALTER TABLE `Student_acc`
  ADD CONSTRAINT `Student_acc_acc_id_pk` FOREIGN KEY (`accounts_id`) REFERENCES `ACCOUNTS` (`Accounts_id`);

--
-- Constraints for table `VOLUNTEER`
--
ALTER TABLE `VOLUNTEER`
  ADD CONSTRAINT `volunteer_acc_id_pk` FOREIGN KEY (`accounts_id`) REFERENCES `Accounts` (`Accounts_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
